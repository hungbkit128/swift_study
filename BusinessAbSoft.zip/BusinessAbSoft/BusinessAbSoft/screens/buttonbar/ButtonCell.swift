//
//  ButtonCell.swift
//  BusinessAbSoft
//
//  Created by Tran Van Hung on 10/12/17.
//  Copyright © 2017 hungtv. All rights reserved.
//

import UIKit

class ButtonCell: UICollectionViewCell {

    @IBOutlet weak var iconImage: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
