//
//  RegisterResponseData.swift
//  BusinessAbSoft
//
//  Created by Tran Van Hung on 10/16/17.
//  Copyright © 2017 hungtv. All rights reserved.
//

import Foundation
class RegisterResponseData: ResponseCommon {
    var stringPlus:String?
}
