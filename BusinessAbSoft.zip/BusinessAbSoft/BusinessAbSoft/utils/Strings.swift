//
//  Strings.swift
//  BusinessAbSoft
//
//  Created by Tran Van Hung on 11/1/17.
//  Copyright © 2017 hungtv. All rights reserved.
//

import Foundation
class Strings {
    static let APP_NAME = "A B S O F T"
    static let OK = "Đồng ý"
    static let CANCEL = "Huỷ"
}
